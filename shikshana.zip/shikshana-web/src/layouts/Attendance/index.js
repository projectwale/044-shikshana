/**
=========================================================
* Shikshana MUI - v3.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-material-ui
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/
import React, { useEffect, useState } from 'react';

// Shikshana MUI components
import ArgonBox from "components/ArgonBox";
import ArgonButton from "components/ArgonButton";
import Table from 'react-bootstrap/Table';
import Icon from "@mui/material/Icon";
import ArgonTypography from "components/ArgonTypography";
import ArgonInput from "components/ArgonInput";

// Authentication layout components
import IllustrationLayout from "layouts/authentication/components/IllustrationLayout1";

import axios from "axios";
import { ipofserver } from 'global';

function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}


// Image
const bgImage =
  "https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/signin-ill.jpg";

function Illustration() {

  const [currentDate, setCurrentDate] = useState(new Date());
  const [hospitals, setHospitals] = useState([]);
  const [hospitals1, setHospitals1] = useState([]);

  const [inputField, setInputField] = useState({
    attdate: '',
  })

  const inputsHandler = (e) => {
    const { name, value } = e.target;
    setInputField((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  }

  useEffect(() => {
    axios.get(`${ipofserver}getAllStud/${localStorage.getItem('AdminLoginUserstd')}`)
      // .then(res => res.json())
      .then(data => {
        // alert(data.data)
        setHospitals(data.data);
      })
      .catch(err => {
        console.log(err);
      })
  }, [])

  useEffect(() => {
    document.getElementById("dateInput").value = formatDate(currentDate);
    axios.get(`${ipofserver}getAllAttendance/${formatDate(currentDate)}/${localStorage.getItem('AdminLoginUserstd')}`)
      // .then(res => res.json())
      .then(data => {
        // alert(data.data)
        setHospitals1(data.data);
      })
      .catch(err => {
        console.log(err);
      })
  }, [currentDate]);

  const handleDateChange = (event) => {
    const selectedDate = new Date(event.target.value);
    setCurrentDate(selectedDate);
  };

  const submitButton = () => {
    if (inputField.attdate == '') {
      alert("Please select attendance date !")
    }
    else {
      const finallst = [];
      hospitals.map(async (inputid) => {
        console.log(inputid[0]);
        var x = document.getElementById('present' + inputid[0]).checked;
        var y = document.getElementById('absent' + inputid[0]).checked;
        console.log(x, y);
        if (x == true) {
          finallst.push('Present')
        }
        else if (y == true) {
          finallst.push('Absent')
        }
        else {
          finallst.push('')
        }
      })
      var bool = true
      finallst.map((ele) => {
        if (ele == '') {
          bool = false
        }
      })
      if (!bool) {
        alert("Please check attendance!")
      }
      else {
        // alert(inputField.attdate)
        axios.post(ipofserver + 'markAttendance', {
          formlist: hospitals,
          attendance: finallst,
          attdate: inputField.attdate
        })
          .then(function (response) {
            if (response.data == "success") {
              alert("Attendance submited successfully !")
              window.location.href = '/attendance'
            }
            else {
              alert("Something wrong !")
            }
          })
          .catch(function (error) {
            return error;
          });
      }
    }
  }

  return (
    <IllustrationLayout
      title="Attendance"
      description="Mark student attendance"
      illustration={{
        image: bgImage,
        title: '"Attention is the new currency"',
        description:
          "The more effortless the writing looks, the more effort the writer actually put into the process.",
      }}
    >
      <ArgonBox component="form" role="form">
        <Table striped bordered hover>
          <thead style={{ fontSize: 18 }}>
            <tr>
              <th>Student Id</th>
              <th>Student details</th>
              <th>Standard</th>
              <th>
                Check attendance
                <ArgonInput
                  type="date"
                  name="attdate" value={inputField.attdate}
                  onChange={inputsHandler}
                />
              </th>
            </tr>
          </thead>
          <tbody style={{ fontSize: 16 }}>
            {hospitals.map((hospital, index) => (
              <tr key={index}>
                <td>{hospital[0]}</td>
                <td>
                  <p style={{ marginBottom: '1px' }}><strong>{hospital[2]}</strong></p>
                  <p>{hospital[3]}</p>
                </td>
                <td>{hospital[5]}</td>
                <td>
                  <label style={{ margin: 3 }}>
                    <input
                      style={{ margin: 5 }}
                      type="radio"
                      value="Present"
                      id={'present' + hospital[0]}
                      name={'attendance' + hospital[0]}
                    />
                    Present
                  </label>
                  <label style={{ margin: 3 }}>
                    <input
                      style={{ margin: 5 }}
                      type="radio"
                      value="Absent"
                      id={'absent' + hospital[0]}
                      name={'attendance' + hospital[0]}
                    />
                    Absent
                  </label>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

        <ArgonBox mt={4} mb={5}>
          <ArgonButton color="info" size="large" onClick={submitButton} fullWidth>
            Submit
          </ArgonButton>
        </ArgonBox>
      </ArgonBox>

      <ArgonBox component="form" role="form">
        <ArgonTypography variant="h4" fontWeight="medium" mb={5}>
          <ArgonBox mb={3}>
            Marked Attendance of date
            <ArgonInput
              type="date"
              id="dateInput"
              onChange={handleDateChange}
            />
          </ArgonBox>
          <Table striped bordered hover>
            <thead style={{ fontSize: 18 }}>
              <tr>
                <th>Student Id</th>
                <th>Student details</th>
                <th>Standard</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody style={{ fontSize: 16 }}>
              {hospitals1.map((hospital, index) => (
                <tr key={index}>
                  <td>{hospital[0]}</td>
                  <td>
                    <p style={{ marginBottom: '1px' }}><strong>{hospital[1]}</strong></p>
                    <p>{hospital[2]}</p>
                  </td>
                  <td>{hospital[3]}</td>
                  <td style={{ color: hospital[4] == 'Absent' ? 'red' : 'green' }}>{hospital[4]}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </ArgonTypography>
      </ArgonBox>
    </IllustrationLayout>
  );
}

export default Illustration;
