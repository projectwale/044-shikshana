/**
=========================================================
* Shikshana MUI - v3.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-material-ui
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// @mui material components
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import ArgonButton from "components/ArgonButton";

import preview from "../../../src/assets/images/browse.jpg";
// Shikshana MUI components
import ArgonBox from "components/ArgonBox";
import ArgonTypography from "components/ArgonTypography";

// Shikshana MUI example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import Footer from "examples/Footer";

// Overview page components
import Header from "layouts/userSyllabus/components/Header";
import React, { useEffect, useState } from 'react';

import axios from "axios";
import { ipofserver } from 'global';
import fileDownload from 'js-file-download'

const bgImage =
  "https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/profile-layout-header.jpg";

function Overview() {
  const [file, setFile] = useState('None');
  useEffect(() => {
    axios.get(`${ipofserver}getReoprtCard/${localStorage.getItem('LoginUsername')}/${localStorage.getItem('LoginUserstd')}`)
      .then(data => {
        setFile(data.data);
      })
      .catch(err => {
        console.log(err);
      })
  }, [])

  const DownloadButton = (link, filename) => {
    const parts = filename.split("/");
    const imageName = parts[parts.length - 1];
    axios.get(link, {
      responseType: 'blob',
    })
      .then((res) => {
        fileDownload(res.data, imageName)
      })
  }

  return (
    <DashboardLayout
      sx={{
        backgroundImage: ({ functions: { rgba, linearGradient }, palette: { gradients } }) =>
          `${linearGradient(
            rgba(gradients.info.main, 0.6),
            rgba(gradients.info.state, 0.6)
          )}, url(${bgImage})`,
        backgroundPositionY: "50%",
      }}
    >
      <Header />
      <ArgonBox mb={3} mt={-10}>
        <Card>
          <ArgonBox pt={2} px={2}>
            <ArgonBox mb={5} mt={1}>
              <ArgonTypography variant="h4" fontWeight="medium">
                Report Card
              </ArgonTypography>

              <div className="App mt-3">
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
                  <img
                    src={file == 'None' ? preview : ipofserver + file}
                    style={{
                      width: 430, height: 330, borderWidth: 2, borderStyle: 'dashed', borderColor: 'black', borderRadius: 4
                    }} />
                </div>
              </div>
              {file != 'None' ? (
                <ArgonBox m={2}>
                  <ArgonButton color="info" size="large" style={{ fontSize: 17 }}
                    onClick={event => DownloadButton(ipofserver + file, file)}
                    fullWidth>
                    Download file
                  </ArgonButton>
                </ArgonBox>
              ) :
                null}
            </ArgonBox>
          </ArgonBox>
        </Card>
      </ArgonBox>

      <Footer />
    </DashboardLayout>
  );
}

export default Overview;
